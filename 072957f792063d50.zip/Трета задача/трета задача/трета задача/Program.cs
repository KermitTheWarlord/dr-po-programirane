﻿using System;

namespace трета_задача
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This program will tell you in which quadrant your coordinates will end up");
            Console.WriteLine("Enter your X coordinate");
            int X = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your Y coordinate");
            int Y = Convert.ToInt32(Console.ReadLine());

            if ((X >= 0) && (Y >= 0))
            {
                Console.WriteLine("Your coordinate is in the first quadrant");
            }
            if ((X <= 0) && (Y >= 0))
            {
                Console.WriteLine("Your coordinate is in the second quadrant");
            }
            if ((X <= 0) && (Y <= 0))
            {
                Console.WriteLine("Your coordinate is in the third quadrant");
            }
            if ((X >= 0) && (Y <= 0))
            {
                Console.WriteLine("Your coordinate is in the fourth quadrant");
            }

            else if ((X == 0) && (Y == 0)) 
            {
                Console.WriteLine("you are not in any of the quadrants you are exactly in the middle");
            }

        }
    }
}
