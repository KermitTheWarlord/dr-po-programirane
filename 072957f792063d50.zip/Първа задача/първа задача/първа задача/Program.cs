﻿using System;

namespace първа_задача
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter three numbers and I will check in which order they are in ");
            double X, Y, Z;
            Console.WriteLine("X=");
            X = double.Parse(Console.ReadLine());
            Console.WriteLine("Y=");
            Y = double.Parse(Console.ReadLine());
            Console.WriteLine("Z=");
            Z = double.Parse(Console.ReadLine());
            if ((X > Y) && (Y > Z))
            {
                Console.WriteLine("The numbers which you entered were in an ascending order");
            }
            else
            {
                Console.WriteLine("The numbers which you entered were not in a descending order");
            }
        }
    }
}
